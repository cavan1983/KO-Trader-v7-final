# GitHub-da Fayllari Duzeltmek - REAL LEARNING

## 1. GitHub Repo-ya gir
https://github.com/senin-adin/KO-Trader-v7-final

## 2. Kohne fayllari sil
- train_nvda_real_ai.py (kohne) -> sil
- train_nvda_REAL_LEARNING.py (ici yml olan) -> sil
- Robot-NVDA-... kimi fayllar -> sil

## 3. Yeni fayllari yukle (Add file -> Upload files)
Bu qovluqdan:
- train_nvda_REAL_LEARNING.py -> kok'e
- robot.py -> kok'e (kohne robot.py-ni evez edir)
- config.py -> kok'e (TICKERS = ["NVDA"])
- .github/workflows/retrain_weekly.yml -> .github/workflows/ qovluguna

## 4. Commit
Commit changes -> Commit directly to main

## 5. Sonra PC-de Download
Code -> Download ZIP -> ac -> icinde data/final/ qovlugu olacaq

## 6. PC-de oyret
pip install yfinance pandas numpy scikit-learn requests pytz
python train_nvda_REAL_LEARNING.py
